#!/usr/bin/env python
"""
GPU Transfer times graph
"""
import matplotlib.pyplot as plt
import numpy as np
import csv
import operator

class GPUClass:
    def __init__(self,filename):
        self.computerName = None
        self.gpuType = None
        self.memory = 0
        self.N = []
        self.toGpuTimes = []
        self.funcTimes = []
        self.fromGpuTimes = []
        self.dataTransferTotals = []
        self.totalAppTimes = []
        self.memoryTransferred = []
        self.percentDataTransfer = []
        dataReader = csv.reader(open(filename,'rU'))
        nextLine = dataReader.next()
        self.computerName = nextLine[0]
        self.gpuType = nextLine[1]
        self.memory = nextLine[2]
        nextLine = dataReader.next()
        self.functionName = nextLine[2]
        self.N,self.toGpuTimes,self.funcTimes,self.fromGpuTimes,self.memoryTransferred = zip(*dataReader)
        self.N = map(int,self.N)
        self.toGpuTimes = map(float,self.toGpuTimes)
        self.funcTimes = map(float,self.funcTimes)
        self.fromGpuTimes = map(float,self.fromGpuTimes)
        self.memoryTransferred = map(int,self.memoryTransferred)
        
        
        for i in range(len(self.N)):
            self.dataTransferTotals.append(self.toGpuTimes[i]+self.fromGpuTimes[i])
            self.totalAppTimes.append(self.toGpuTimes[i]+self.funcTimes[i]+self.fromGpuTimes[i])
            self.percentDataTransfer.append(self.dataTransferTotals[i]/self.totalAppTimes[i])
    
    def printData(self):
        print "--------------------"
        print self.computerName,self.gpuType,self.memory,self.functionName
        print
        print "N","Transfer to GPU(ms)","Function Time(ms)","From GPU(ms)","Mem(B)","%"
        for i,n in enumerate(self.N):
            print n,self.toGpuTimes[i],self.funcTimes[i],self.fromGpuTimes[i],self.memoryTransferred[i],self.percentDataTransfer[i]
        print "....................."


gpus = ('TeslaC2050.csv','gtx480.csv','9800GT.csv','330M.csv')
gpuData = []
for gpu in gpus:
    gpuData.append(GPUClass(gpu))

fig = plt.figure()
ax = fig.add_subplot(121)

graphMin = 0
graphMax = 8
ind = np.arange(graphMax-graphMin)    # the x locations for the groups
barWidth = 1./len(gpuData)*.8
bars = []

for idx,gpu in enumerate(gpuData):
    stacks = []
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.toGpuTimes[graphMin:graphMax], barWidth, color='r'))
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.funcTimes[graphMin:graphMax], barWidth, color = 'orange',bottom=gpu.toGpuTimes[graphMin:graphMax]))
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.fromGpuTimes[graphMin:graphMax], barWidth,color = 'b',bottom=map(operator.add,gpu.funcTimes[graphMin:graphMax],gpu.toGpuTimes[graphMin:graphMax])))
    # for i in ind:
#         percentStr = str(int(round(gpu.percentDataTransfer[i+graphMin]*100,0)))+"%"
#         plt.text(i+float(idx)/len(gpuData)*.8,gpu.totalAppTimes[i+graphMin]+0.5,percentStr)
    #plt.text(float(idx)/len(gpuData)*.8+barWidth/2.,gpu.totalAppTimes[graphMin]-len(gpu.gpuType)+100,gpu.gpuType,rotation='vertical')
    plt.text(float(idx)/len(gpuData)*.8+barWidth/2.,10,gpu.gpuType,rotation='vertical',fontsize='10')
    
    #plt.scatter(ind+float(idx)/len(gpuData)*.8+barWidth/2.,gpu.totalAppTimes[graphMin:graphMax],label='a')
    bars.append(list(stacks))


plt.xticks(ind+barWidth*len(gpuData)/2.,gpuData[0].N[graphMin:graphMax])

#for idx,gpu in enumerate(gpuData):
#    ax.annotate(gpu.gpuType,xy=(ind[0]+idx*barWidth+barWidth/float(len(gpuData)),gpu.totalAppTimes[0]+len(gpu.gpuType)+1),rotation='vertical')
plt.rc("font",size=16);
plt.ylabel('Time (ms)')
plt.xlabel('Matrix size (N x N)')
plt.title('SGEMM Run Times (small data set)')
plt.legend((bars[0][2][0],bars[0][1][0],bars[0][0][0]),('Data Transfer from GPU','SGEMM Function','Data Transfer to GPU'),loc='upper left')

################### second graph
ax = fig.add_subplot(122)

graphMin = 8
graphMax = 16
ind = np.arange(graphMax-graphMin)    # the x locations for the groups
barWidth = 1./len(gpuData)*.8
bars = []

for idx,gpu in enumerate(gpuData):
    stacks = []
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.toGpuTimes[graphMin:graphMax], barWidth, color='r'))
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.funcTimes[graphMin:graphMax], barWidth, color = 'orange',bottom=gpu.toGpuTimes[graphMin:graphMax]))
    stacks.append(plt.bar(ind+float(idx)/len(gpuData)*.8, gpu.fromGpuTimes[graphMin:graphMax], barWidth,color = 'b',bottom=map(operator.add,gpu.funcTimes[graphMin:graphMax],gpu.toGpuTimes[graphMin:graphMax])))
    # for i in ind:
#         percentStr = str(int(round(gpu.percentDataTransfer[i+graphMin]*100,0)))+"%"
#         plt.text(i+float(idx)/len(gpuData)*.8,gpu.totalAppTimes[i+graphMin]+0.5,percentStr)
    #plt.text(float(idx)/len(gpuData)*.8+barWidth/2.,gpu.totalAppTimes[graphMin]-len(gpu.gpuType)+100,gpu.gpuType,rotation='vertical')
    plt.text(float(idx)/len(gpuData)*.8+barWidth/4.,120,gpu.gpuType,rotation='vertical',fontsize='10')
    #plt.scatter(ind+float(idx)/len(gpuData)*.8+barWidth/2.,gpu.totalAppTimes[graphMin:graphMax],label='a')
    bars.append(list(stacks))


plt.xticks(ind+barWidth*len(gpuData)/2.,gpuData[0].N[graphMin:graphMax])

#for idx,gpu in enumerate(gpuData):
#    ax.annotate(gpu.gpuType,xy=(ind[0]+idx*barWidth+barWidth/float(len(gpuData)),gpu.totalAppTimes[0]+len(gpu.gpuType)+1),rotation='vertical')
plt.rc("font",size=16);
plt.ylabel('Time (ms)')
plt.xlabel('Matrix size (N x N)')
plt.title('SGEMM Run Times (large data set)')
plt.legend((bars[0][2][0],bars[0][1][0],bars[0][0][0]),('Data Transfer from GPU','SGEMM Function','Data Transfer to GPU'),loc='upper left')


plt.show()
